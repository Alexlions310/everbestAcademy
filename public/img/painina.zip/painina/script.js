let btns = document.querySelectorAll('.key');
btns.forEach(animatsiya);

function  animatsiya(tugma){
 tugma.addEventListener('click', clicked)

function clicked(){
    tugma.classList.add('active');

    tovushQosh(tugma);
    setTimeout(ajrat , 100)
        function ajrat(){
        tugma.classList.remove('active')
        }
    }
}

 function tovushQosh(tugma){
  
    let tugmaid = tugma.getAttribute('data-xotira');
    document.getElementById(tugmaid).play();
 }


 document.addEventListener('keypress', pressed);

 function pressed(hodisa){
    let harf = hodisa.key;

    if(harf === 's'){
        document.getElementById('C').play();
        document.getElementsByClassName('key')[0].classList.add('active');
        ajratuvchi(0);
    }

    if(harf === 'e'){
        document.getElementById('Db').play();
        document.getElementsByClassName('key')[1].classList.add('active');
        ajratuvchi(1);
    }

    if(harf === 'd'){
        document.getElementById('D').play();
        document.getElementsByClassName('key')[2].classList.add('active');
        ajratuvchi(2);
    }

    if(harf === 'r'){
        document.getElementById('Eb').play();
        document.getElementsByClassName('key')[3].classList.add('active');
        ajratuvchi(3);
    }

    if(harf === 'f'){
        document.getElementById('E').play();
        document.getElementsByClassName('key')[4].classList.add('active');
        ajratuvchi(4);
    }

    if(harf === 'g'){
        document.getElementById('F').play();
        document.getElementsByClassName('key')[5].classList.add('active');
        ajratuvchi(5);
    }

    if(harf === 't'){
        document.getElementById('Gb').play();
        document.getElementsByClassName('key')[6].classList.add('active');
        ajratuvchi(6);
    }

    if(harf === 'h'){
        document.getElementById('G').play();
        document.getElementsByClassName('key')[7].classList.add('active');
        ajratuvchi(7);
    }

    if(harf === 'u'){
        document.getElementById('Ab').play();
        document.getElementsByClassName('key')[8].classList.add('active');
        ajratuvchi(8);
    }

    if(harf === 'j'){
        document.getElementById('A').play();
        document.getElementsByClassName('key')[9].classList.add('active');
        ajratuvchi(9);
    }

    if(harf === 'i'){
        document.getElementById('Bd').play();
        document.getElementsByClassName('key')[10].classList.add('active');
        ajratuvchi(10);
    }

    if(harf === 'k'){
        document.getElementById('B').play();
        document.getElementsByClassName('key')[11].classList.add('active');
        ajratuvchi(11);
    }

    
function ajratuvchi(index){
    setTimeout(ajratish, 200)
    
     function ajratish(){
     document.getElementsByClassName('key')[index].classList.remove('active');
     }
    
    }
 }

